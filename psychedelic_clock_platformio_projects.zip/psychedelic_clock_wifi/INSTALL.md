# Installation Guide - WiFi Clock Version

## Option 1: Flash Pre-built Firmware (Recommended)

**Requirements:**
- esptool.py installed (`pip install esptool`)
- ESP32-2432S028 connected via USB

**Steps:**
1. Put ESP32 in bootloader mode:
   - Hold BOOT button
   - Press RESET while holding BOOT
   - Hold BOOT for 3+ seconds
   - Release BOOT

2. Flash firmware:
```bash
esptool.py --chip esp32 --port /dev/ttyUSB0 --baud 921600 write_flash 0x10000 psychedelic_clock_CLEAN_CLOCK_SET.bin
```

3. Reset device - effects start immediately!

## Option 2: Build from Source

**Requirements:**
- PlatformIO installed
- ESP32-2432S028 hardware

**Steps:**
```bash
cd psychedelic_clock_wifi
pio run              # Build
pio run -t upload    # Flash (device must be in bootloader mode)
```

## WiFi Setup

1. **Connect to AP:**
   - Network: "ClockAP"
   - Password: "clockset123"

2. **Open web interface:**
   - Browser: `http://192.168.4.1`

3. **Set time:**
   - Enter hours (0-23) and minutes (0-59)
   - Click "Set Time"
   - Time remembers until device restart

## Troubleshooting

**Device won't flash:**
- Ensure bootloader mode (BOOT button held during reset)
- Try different baud rate: `--baud 115200`
- Check USB cable and port

**WiFi not working:**
- Reset device and wait 30 seconds for AP to start
- Check WiFi networks for "ClockAP"

**Clock not showing:**
- Use web interface to toggle clock display
- Clock appears in bottom-right corner when enabled

**Effects not changing:**
- Touch screen to advance manually
- Auto-advance happens every 30 seconds

## Hardware Notes
- No external RTC required (software timekeeping)
- Clock resets to boot time on restart (set via web)
- Touch functionality requires XPT2046 touchscreen working