# Psychedelic Clock WiFi Version

**Complete 60-effect psychedelic clock with WiFi web interface for time setting**

## Features
- 🎨 **60 Unique Visual Effects** - Complete collection of psychedelic animations
- 🕒 **Clean Clock Display** - Small time display in bottom-right corner (no text clutter)  
- 📱 **WiFi Web Interface** - Set time via web browser
- 🔄 **Touch Controls** - Tap screen to advance effects manually
- ⚡ **Auto-advance** - Effects change automatically every 30 seconds
- 💾 **Memory Optimized** - 37.9% RAM, 68.0% Flash usage

## Quick Start
1. Flash `psychedelic_clock_CLEAN_CLOCK_SET.bin` to your ESP32-2432S028
2. Connect to WiFi AP "ClockAP" (password: clockset123)
3. Open browser to `192.168.4.1`
4. Set your time and toggle clock display

## Hardware Requirements
- ESP32-2432S028 display module (Cheap Yellow Display)
- No additional RTC module required (software time keeping)

## Build Instructions
```bash
cd psychedelic_clock_wifi
pio run              # Build
pio run -t upload    # Flash to device
```

## Web Interface
- **Clock Toggle**: Turn clock display on/off
- **Time Setting**: Set hours and minutes (remembers until restart)
- **Clean Display**: No annoying status text on screen

## Effects Collection
All 60 effects from the CORESCREENS collection including:
- Mathematical fractals (Mandelbrot, Julia sets)
- Natural phenomena (Fire, Lightning, Rain)
- Particle systems (Starfield, Plasma, DNA Helix)
- Retro gaming (Matrix Rain, Tetris blocks)
- Geometric patterns (Kaleidoscope, Spirals, Tunnels)

**Built: November 23, 2025 09:21 UTC**  
**Status: Production Ready - WiFi Clock Version**